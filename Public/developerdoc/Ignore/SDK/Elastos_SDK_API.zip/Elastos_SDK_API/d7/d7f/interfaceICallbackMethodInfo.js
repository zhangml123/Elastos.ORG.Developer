var interfaceICallbackMethodInfo =
[
    [ "AddCallback", "d7/d7f/interfaceICallbackMethodInfo.html#a481ecb456e5c2d7eaf1ae451a6e3c519", null ],
    [ "CreateDelegateProxy", "d7/d7f/interfaceICallbackMethodInfo.html#a632972d3119497d2309df8590abb1407", null ],
    [ "RemoveCallback", "d7/d7f/interfaceICallbackMethodInfo.html#a9e1e28da138bca8567ede098429270a9", null ]
];