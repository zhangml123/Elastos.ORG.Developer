var indexSectionsWithContent =
{
  0: "_abcdefghijlmopqrstuvwz",
  1: "_aciqr",
  2: "e",
  3: "acdefghimorsuwz",
  4: "em",
  5: "bcdefhilmptuv",
  6: "cpt",
  7: "cpt",
  8: "bcdjrsw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Modules"
};

