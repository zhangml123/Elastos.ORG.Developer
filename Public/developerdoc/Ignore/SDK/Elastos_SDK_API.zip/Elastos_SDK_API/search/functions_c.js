var searchData=
[
  ['unregistercallback',['UnregisterCallback',['../d3/dff/interfaceIDIDManager.html#a7911a118236aea35d8b34be41a727121',1,'IDIDManager']]]
];
