var searchData=
[
  ['delete',['Delete',['../db/d53/interfaceElastos_1_1IO_1_1IPlainFile.html#ae4d268410fa5b37f7b555372769d08d3',1,'Elastos::IO::IPlainFile']]],
  ['destorydid',['DestoryDID',['../d3/dff/interfaceIDIDManager.html#a3c9b19304f42968a79b341c6d07756dd',1,'IDIDManager']]],
  ['destroywallet',['DestroyWallet',['../d4/d74/interfaceIMasterWallet.html#af40aa5deb79114db7d33295b6a19fd68',1,'IMasterWallet::DestroyWallet()'],['../d3/d90/interfaceIMasterWalletManager.html#a474c301907720702a5ae08a4bb484cf2',1,'IMasterWalletManager::DestroyWallet()']]]
];
