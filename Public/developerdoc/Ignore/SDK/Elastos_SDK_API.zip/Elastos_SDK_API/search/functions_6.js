var searchData=
[
  ['hasbase',['HasBase',['../d2/d2d/interfaceIInterfaceInfo.html#a2df50c932be8b7182035a65b2df3d102',1,'IInterfaceInfo']]],
  ['hasbaseclass',['HasBaseClass',['../d1/d77/interfaceIClassInfo.html#abb18a3580a43debfd2bb33e033c714d4',1,'IClassInfo']]],
  ['hasgeneric',['HasGeneric',['../d1/d77/interfaceIClassInfo.html#a0e651b82be39a3bd4aff6499ea4f97b8',1,'IClassInfo']]],
  ['hasinterfaceinfo',['HasInterfaceInfo',['../d1/d77/interfaceIClassInfo.html#ab4723060f78b234a6865b1ebb690cf02',1,'IClassInfo']]]
];
