var searchData=
[
  ['handle32',['Handle32',['../de/d09/group__CARTypesRef.html#ga29c322f09a8c32edee03d0261b0b3cb7',1,'elatypes.h']]],
  ['handle64',['Handle64',['../de/d09/group__CARTypesRef.html#ga6dad6e48f37b25fe02a2a24c9a41317e',1,'elatypes.h']]]
];
