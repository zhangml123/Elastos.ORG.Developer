var searchData=
[
  ['localptr',['LocalPtr',['../d4/d2a/group__ReflectionAPI.html#ga747f2aa17ddf18ebe01dcd54a3eec9a9',1,'ElReflection.car']]]
];
