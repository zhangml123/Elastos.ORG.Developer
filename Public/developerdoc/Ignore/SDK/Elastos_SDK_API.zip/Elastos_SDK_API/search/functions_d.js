var searchData=
[
  ['write',['Write',['../db/d53/interfaceElastos_1_1IO_1_1IPlainFile.html#a3a365959d1ce045714fc6d5f383a7c5b',1,'Elastos::IO::IPlainFile']]]
];
