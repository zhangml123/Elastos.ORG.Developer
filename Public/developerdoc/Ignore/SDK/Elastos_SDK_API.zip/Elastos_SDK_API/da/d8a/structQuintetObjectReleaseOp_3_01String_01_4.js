var structQuintetObjectReleaseOp_3_01String_01_4 =
[
    [ "operator()", "da/d8a/structQuintetObjectReleaseOp_3_01String_01_4.html#a49ea742ed8f09f394824a15b35ff9307", null ]
];