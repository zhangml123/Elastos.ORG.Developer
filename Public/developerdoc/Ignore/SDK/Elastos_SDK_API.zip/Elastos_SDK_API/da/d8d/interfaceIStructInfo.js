var interfaceIStructInfo =
[
    [ "CreateVariable", "da/d8d/interfaceIStructInfo.html#aafc356fe8655938ec8d3c413ff7dddca", null ],
    [ "CreateVariableBox", "da/d8d/interfaceIStructInfo.html#af513298a5a9798bcf2357eb240220784", null ],
    [ "GetAllFieldInfos", "da/d8d/interfaceIStructInfo.html#a035d4db565a0c824768defc0df889a4d", null ],
    [ "GetFieldCount", "da/d8d/interfaceIStructInfo.html#aa7246950174dd9f7319230f92e322758", null ],
    [ "GetFieldInfo", "da/d8d/interfaceIStructInfo.html#aa221b73eaeb366496d2ef7f88e9ffc7c", null ],
    [ "GetModuleInfo", "da/d8d/interfaceIStructInfo.html#afdb7538cb3cb9b85619e76626dabeaa1", null ]
];