var interfaceIFieldInfo =
[
    [ "GetName", "da/d0a/interfaceIFieldInfo.html#acb1b9c8a12fff05accb9693692900fbd", null ],
    [ "GetTypeInfo", "da/d0a/interfaceIFieldInfo.html#a430859ec84feb5c8780d61ff8f843ebd", null ]
];