var structQuintetObjectCopyOp =
[
    [ "operator()", "da/d55/structQuintetObjectCopyOp.html#a38d57d5e269b4960cb722be90085e93a", null ],
    [ "operator()", "da/d55/structQuintetObjectCopyOp.html#a5b5cc4c87aefabd4396c99ccee3f2e67", null ],
    [ "operator()", "da/d55/structQuintetObjectCopyOp.html#a388688d6efbbf57dbfc4a3fd955d4735", null ]
];