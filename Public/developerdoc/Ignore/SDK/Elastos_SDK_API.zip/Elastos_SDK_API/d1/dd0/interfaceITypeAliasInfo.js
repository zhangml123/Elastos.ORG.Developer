var interfaceITypeAliasInfo =
[
    [ "GetModuleInfo", "d1/dd0/interfaceITypeAliasInfo.html#af24ffe1f92243912355cc23aefe39ff7", null ],
    [ "GetName", "d1/dd0/interfaceITypeAliasInfo.html#ab76650da129127a85efd152a3f1b32e1", null ],
    [ "GetPtrLevel", "d1/dd0/interfaceITypeAliasInfo.html#a2e2ee580c5e1fc9c0f021593eaad62fc", null ],
    [ "GetTypeInfo", "d1/dd0/interfaceITypeAliasInfo.html#a4fb4a70d8c17e49bbbb95af998ed9095", null ],
    [ "IsDummy", "d1/dd0/interfaceITypeAliasInfo.html#a70d145e3e65305bd9fa98f67297045da", null ]
];