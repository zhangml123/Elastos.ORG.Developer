var structCopyOpWrapper =
[
    [ "operator()", "d1/dcb/structCopyOpWrapper.html#a280a76968f2efa9f1ff6a2bc5a28a3a3", null ]
];