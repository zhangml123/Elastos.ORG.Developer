var interfaceIDIDChecker =
[
    [ "CheckDID", "d5/d40/interfaceIDIDChecker.html#a50b4e8813b5a63426ba0484965aa15eb", null ],
    [ "CheckSign", "d5/d40/interfaceIDIDChecker.html#ac8fcde90ef665a093384f82a5df3755d", null ],
    [ "GetAllKeys", "d5/d40/interfaceIDIDChecker.html#ad3bf8759b42bcbbfa5368d813d5b7944", null ],
    [ "GetHistoryValue", "d5/d40/interfaceIDIDChecker.html#a0e57d156dca571b2e90a9c1fa7b6ae53", null ],
    [ "GetPublicKey", "d5/d40/interfaceIDIDChecker.html#a1f92771aae8d1ad77a6dbd113636c036", null ],
    [ "GetValue", "d5/d40/interfaceIDIDChecker.html#a16c2a8f315b0d07eed19746abd41a244", null ]
];