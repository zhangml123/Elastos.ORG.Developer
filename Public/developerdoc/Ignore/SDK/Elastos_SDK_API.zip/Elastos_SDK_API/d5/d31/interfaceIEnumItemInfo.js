var interfaceIEnumItemInfo =
[
    [ "GetEnumInfo", "d5/d31/interfaceIEnumItemInfo.html#a5f2f4036db92c5f85c091dd67e9d0f44", null ],
    [ "GetName", "d5/d31/interfaceIEnumItemInfo.html#a0080151c9f38a28dc28cbfd752862010", null ],
    [ "GetValue", "d5/d31/interfaceIEnumItemInfo.html#a7c862cfe40b2d203e80d841f601cf7b0", null ]
];