var structCopyOpImpl_3_01T_00_01TRUE_01_4 =
[
    [ "operator()", "d5/d85/structCopyOpImpl_3_01T_00_01TRUE_01_4.html#a7e6c92130b6ccfa04014df97dfb184e9", null ]
];