var classCMasterWalletManager =
[
    [ "constructor", "de/ded/classCMasterWalletManager.html#a3e5c468427b9c9325139d56e889e2001", null ]
];