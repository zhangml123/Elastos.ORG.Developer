var namespaceElastos_1_1IO =
[
    [ "CPlainFile", "d2/d57/classElastos_1_1IO_1_1CPlainFile.html", "d2/d57/classElastos_1_1IO_1_1CPlainFile" ],
    [ "IPlainFile", "db/d53/interfaceElastos_1_1IO_1_1IPlainFile.html", "db/d53/interfaceElastos_1_1IO_1_1IPlainFile" ]
];