var structQuintetObjectReleaseOp_3_01AutoPtr_3_01T_01_4_01_4 =
[
    [ "operator()", "de/d9f/structQuintetObjectReleaseOp_3_01AutoPtr_3_01T_01_4_01_4.html#a11b603535c2f227d63ac82b1c4bffc70", null ]
];