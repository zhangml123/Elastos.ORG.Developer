var interfaceIDelegateProxy =
[
    [ "GetCallbackInvocation", "de/d92/interfaceIDelegateProxy.html#a1f683e92465222ed33335cfe82e0b667", null ],
    [ "GetCallbackMethodInfo", "de/d92/interfaceIDelegateProxy.html#a43978a294d738e84ce7aff4457979d39", null ],
    [ "GetDelegate", "de/d92/interfaceIDelegateProxy.html#a3ef621ad9d819bbb5e6a9b596380edb5", null ],
    [ "GetTargetMethod", "de/d92/interfaceIDelegateProxy.html#adf3ae558cd452a4bb65c8719bacdce7d", null ],
    [ "GetTargetObject", "de/d92/interfaceIDelegateProxy.html#a05cf2d1e3a3a0ad1171d2de522e4bef9", null ]
];