var interfaceIDIDManagerCallback =
[
    [ "OnIdStatusChanged", "d0/d5a/interfaceIDIDManagerCallback.html#ab5bc14a1d816fbad938d834e44d97389", null ]
];