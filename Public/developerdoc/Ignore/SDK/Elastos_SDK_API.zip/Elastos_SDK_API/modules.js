var modules =
[
    [ "BaseTypesRef", "de/d7e/group__BaseTypesRef.html", "de/d7e/group__BaseTypesRef" ],
    [ "CARTypesRef", "de/d09/group__CARTypesRef.html", "de/d09/group__CARTypesRef" ],
    [ "CarrierAPI", "d4/daa/group__CarrierAPI.html", "d4/daa/group__CarrierAPI" ],
    [ "DIDAPI", "d4/d12/group__DIDAPI.html", "d4/d12/group__DIDAPI" ],
    [ "JavaCarManagerAPI", "dd/d02/group__JavaCarManagerAPI.html", "dd/d02/group__JavaCarManagerAPI" ],
    [ "ReflectionAPI", "d4/d2a/group__ReflectionAPI.html", "d4/d2a/group__ReflectionAPI" ],
    [ "ServiceManagerAPI", "db/d85/group__ServiceManagerAPI.html", "db/d85/group__ServiceManagerAPI" ],
    [ "WalletAPI", "db/dd2/group__WalletAPI.html", "db/dd2/group__WalletAPI" ]
];