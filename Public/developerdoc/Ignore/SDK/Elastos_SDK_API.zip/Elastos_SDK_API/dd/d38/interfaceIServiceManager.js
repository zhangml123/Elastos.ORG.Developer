var interfaceIServiceManager =
[
    [ "AddService", "dd/d38/interfaceIServiceManager.html#add7d2cc3ed0ca5e7c29f44340d2386ee", null ],
    [ "GetService", "dd/d38/interfaceIServiceManager.html#a286dfca8e3c97925411d79580f0a1362", null ]
];