var group__JavaCarManagerAPI =
[
    [ "IJavaCarManager", "d4/d7b/interfaceIJavaCarManager.html", [
      [ "AddCarObject", "d4/d7b/interfaceIJavaCarManager.html#a256d90543bf6859823fe554765257492", null ],
      [ "GetCarObject", "d4/d7b/interfaceIJavaCarManager.html#a55fd5d9aa339adc9a9f94a9cee7ee37f", null ],
      [ "GetJavaObject", "d4/d7b/interfaceIJavaCarManager.html#a87a156ca07c380eb3afa6000f059c619", null ],
      [ "RemoveCarObject", "d4/d7b/interfaceIJavaCarManager.html#afd8336d8179aa1f4dfef07aa53ae5784", null ]
    ] ]
];