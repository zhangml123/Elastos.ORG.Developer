var interfaceISubWallet =
[
    [ "AddCallback", "dd/d67/interfaceISubWallet.html#a440ca0fbe5eed0696d819194bae739d7", null ],
    [ "CalculateTransactionFee", "dd/d67/interfaceISubWallet.html#a14f133f59c4a2e1b9c02039dfc070b67", null ],
    [ "CheckSign", "dd/d67/interfaceISubWallet.html#a3630513f1933cd6301d9b6eb093cda4c", null ],
    [ "CreateAddress", "dd/d67/interfaceISubWallet.html#adaf388969f34c2aa1207dcec35865d46", null ],
    [ "CreateMultiSignAddress", "dd/d67/interfaceISubWallet.html#a11537ecb8879f74b92270b6447e52429", null ],
    [ "CreateMultiSignTransaction", "dd/d67/interfaceISubWallet.html#abde448fd70e3416a91fb4d64e9531f54", null ],
    [ "CreateTransaction", "dd/d67/interfaceISubWallet.html#ac00212a67827d516572a3478f3a2b5b2", null ],
    [ "GetAllAddress", "dd/d67/interfaceISubWallet.html#a0112d7ba6e3c1a073af0ddf308078a70", null ],
    [ "GetAllTransaction", "dd/d67/interfaceISubWallet.html#ab8b9a277679a02fe2cea83f5b5aa16bd", null ],
    [ "GetBalance", "dd/d67/interfaceISubWallet.html#a8cd6a8f3c0df817a9ece4938f336d24a", null ],
    [ "GetBalanceInfo", "dd/d67/interfaceISubWallet.html#afe7fe11e714fb3da895a2b8965f32565", null ],
    [ "GetBalanceWithAddress", "dd/d67/interfaceISubWallet.html#aeb9d30e0b4a7df0bac69cbd01392c87d", null ],
    [ "GetChainId", "dd/d67/interfaceISubWallet.html#a89a2c8776388966f40a379a9f1032ccf", null ],
    [ "RemoveCallback", "dd/d67/interfaceISubWallet.html#a67ff59f6901e99ac86d94fed0c1c8802", null ],
    [ "SendRawTransaction", "dd/d67/interfaceISubWallet.html#aeaa1c9d6f17dfec16ca4f50fa50066f9", null ],
    [ "Sign", "dd/d67/interfaceISubWallet.html#ad68877661080cd5690fcc446ec337cbb", null ]
];