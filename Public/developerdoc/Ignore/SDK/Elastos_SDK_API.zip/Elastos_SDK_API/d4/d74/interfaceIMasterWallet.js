var interfaceIMasterWallet =
[
    [ "ChangePassword", "d4/d74/interfaceIMasterWallet.html#aca23d07f134baa51261ed6165f9ce13b", null ],
    [ "CheckSign", "d4/d74/interfaceIMasterWallet.html#aa1c4eb0e69d86a51d754a205802388eb", null ],
    [ "CreateSubWallet", "d4/d74/interfaceIMasterWallet.html#a79351fec9349b0794db6d8cf4d16b885", null ],
    [ "DestroyWallet", "d4/d74/interfaceIMasterWallet.html#af40aa5deb79114db7d33295b6a19fd68", null ],
    [ "GetAllSubWallets", "d4/d74/interfaceIMasterWallet.html#ae6635c6a2e5a70f151272ff92e7e6f21", null ],
    [ "GetId", "d4/d74/interfaceIMasterWallet.html#acc9f1b36d07b1bb4d95633fa45af3a7b", null ],
    [ "GetPublicKey", "d4/d74/interfaceIMasterWallet.html#a871a2630c35e606f9765c43f28778186", null ],
    [ "GetSupportedChains", "d4/d74/interfaceIMasterWallet.html#af60fdb7d1abc1c908b97c9fdfd9bd84f", null ],
    [ "IsAddressValid", "d4/d74/interfaceIMasterWallet.html#ace25232f8ae3b9d166bb76fe9574dfbd", null ],
    [ "RecoverSubWallet", "d4/d74/interfaceIMasterWallet.html#ab9addd4528fd4ae6804d2f8f737d2846", null ],
    [ "Sign", "d4/d74/interfaceIMasterWallet.html#ac97b6817a9e58d8f37fd8f377f257f96", null ]
];