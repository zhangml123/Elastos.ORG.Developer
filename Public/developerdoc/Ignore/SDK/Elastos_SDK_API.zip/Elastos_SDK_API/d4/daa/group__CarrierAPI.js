var group__CarrierAPI =
[
    [ "ICarrier", "d3/d85/interfaceICarrier.html", [
      [ "AccpetFriendRequest", "d3/d85/interfaceICarrier.html#ae9227c870f7d31d566fcd5444c59924a", null ],
      [ "AddCarrierNodeListener", "d3/d85/interfaceICarrier.html#ae1a1c973604663b3b49a444c8cfac4a3", null ],
      [ "AddFriend", "d3/d85/interfaceICarrier.html#af6b0d9664558b8d9e6af8e93389a7b70", null ],
      [ "ClosePortForwarding", "d3/d85/interfaceICarrier.html#a7478cf74ec27f37ee94ec509b403c6f3", null ],
      [ "Export", "d3/d85/interfaceICarrier.html#a345c903a1d7f1fcb22b18649b3caf362", null ],
      [ "GetAddress", "d3/d85/interfaceICarrier.html#a04e3ef835fc4cdd8c5659b3d27bcd0d8", null ],
      [ "GetFriend", "d3/d85/interfaceICarrier.html#a792c9bdf8fcc34c0c1b7321c6cebed54", null ],
      [ "GetFriends", "d3/d85/interfaceICarrier.html#a98f0dbdb881574f7961eaa59c2b7eca7", null ],
      [ "GetUserid", "d3/d85/interfaceICarrier.html#a917739288450a4a2aad507f0bb3cce1f", null ],
      [ "Import", "d3/d85/interfaceICarrier.html#ab0f1f67a07fa6c7078c5b8642f886b83", null ],
      [ "IsOnline", "d3/d85/interfaceICarrier.html#a2d1178af72324220bfcbd54fd4fd7a18", null ],
      [ "OpenPortForwarding", "d3/d85/interfaceICarrier.html#afc66053efe07c6b4f553d84d250e9b46", null ],
      [ "RegenerateAddress", "d3/d85/interfaceICarrier.html#a205d277042d40a60eef5fc8405b4682f", null ],
      [ "RemoveCarrierNodeListener", "d3/d85/interfaceICarrier.html#adcdb0bd99f1ccf5617da1f270852819f", null ],
      [ "RemoveFriend", "d3/d85/interfaceICarrier.html#a4d22594e3774db6416c676bd9474cb87", null ],
      [ "SendMessage", "d3/d85/interfaceICarrier.html#aa0efa51ec741a4b33af21fb80ea20c5f", null ],
      [ "Start", "d3/d85/interfaceICarrier.html#a901d45366d7b7b2afbe025ce87d9bcc0", null ],
      [ "Stop", "d3/d85/interfaceICarrier.html#abf49348546f71e10bbc770a2601accdf", null ]
    ] ],
    [ "ICarrierListener", "d6/d76/interfaceICarrierListener.html", [
      [ "OnConnectionChanged", "d6/d76/interfaceICarrierListener.html#a0f2def6821a38876a58893ee3f3c7d5e", null ],
      [ "OnFriendConnetionChanged", "d6/d76/interfaceICarrierListener.html#a0d35e556bb45eb6019cbc8e3b795e929", null ],
      [ "OnFriendRequest", "d6/d76/interfaceICarrierListener.html#a88548f9dd891078e2d13cc9cd6582781", null ],
      [ "OnIdle", "d6/d76/interfaceICarrierListener.html#a4d43b185fee88a5c8d0ca5fb57f4896e", null ],
      [ "OnMessageReceived", "d6/d76/interfaceICarrierListener.html#a916b97bdb533a550976682e2c15b695d", null ],
      [ "OnPortForwardingRequest", "d6/d76/interfaceICarrierListener.html#af9eeb8827f1b2a5fa64bfa3dbfd2a234", null ],
      [ "OnPortForwardingResult", "d6/d76/interfaceICarrierListener.html#ac16a4ac30dc0afed96a27adc859bbf0d", null ],
      [ "OnReady", "d6/d76/interfaceICarrierListener.html#a20c713b710f20cef20fd5194d1ebae65", null ]
    ] ],
    [ "IFriend", "dc/ddd/interfaceIFriend.html", [
      [ "GetLabel", "dc/ddd/interfaceIFriend.html#ac206993268c1abe21e8fb467444ad955", null ],
      [ "GetName", "dc/ddd/interfaceIFriend.html#aa46a7f570fb370c5c3ae6404c1daeff8", null ],
      [ "GetUid", "dc/ddd/interfaceIFriend.html#a44201d0f299db1e27230b5416916f8bb", null ],
      [ "IsOnline", "dc/ddd/interfaceIFriend.html#a826247d9fc1b1be4d0191c333dab5e1e", null ],
      [ "SetLabel", "dc/ddd/interfaceIFriend.html#a62e8942e1e4e11543b4c73ed3b580410", null ]
    ] ],
    [ "E_CARRIER_ERROR", "d4/daa/group__CarrierAPI.html#gaaf0956af6677568d6040a78b3fc8c568", null ],
    [ "E_CARRIER_NOT_READY", "d4/daa/group__CarrierAPI.html#gaa9f3ad552eccc474c3a0ce3b3f0e8b34", null ],
    [ "E_CLOSE_PORT_FORWARDING", "d4/daa/group__CarrierAPI.html#ga121da7e516428a8d487ff761fa32f0ac", null ],
    [ "E_INCORRECT_STATE", "d4/daa/group__CarrierAPI.html#ga07a2c0f9fbf9cb29feed681d66c654fa", null ],
    [ "E_INVITE", "d4/daa/group__CarrierAPI.html#gac0533f9ca450586bdf41a1281c1a5dbf", null ],
    [ "E_REMOVE_STREAM", "d4/daa/group__CarrierAPI.html#ga112fdedec1a773c6d411f451249c3cb3", null ]
];