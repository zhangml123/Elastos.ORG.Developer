var struct__EGuid =
[
    [ "mCarcode", "d4/d8e/struct__EGuid.html#a504d9644919f36669440d2127a6df64c", null ],
    [ "mClsid", "d4/d8e/struct__EGuid.html#a953ec99f9e5c8a9b910eec404bd486b4", null ],
    [ "mUunm", "d4/d8e/struct__EGuid.html#aab8e631a19c059bac7e480f68da3fd45", null ]
];