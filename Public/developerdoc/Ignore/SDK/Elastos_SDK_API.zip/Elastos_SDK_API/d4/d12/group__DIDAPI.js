var group__DIDAPI =
[
    [ "CDIDChecker", "d1/d21/classCDIDChecker.html", null ],
    [ "CDIDManager", "dc/d9d/classCDIDManager.html", null ],
    [ "IDID", "d3/da5/interfaceIDID.html", [
      [ "CheckSign", "d3/da5/interfaceIDID.html#a7abbfe689e2364c2aa64822178c99534", null ],
      [ "GenerateProgram", "d3/da5/interfaceIDID.html#a6ef1cf2a4845e68c22bb56ebb8af1341", null ],
      [ "GetAllKeys", "d3/da5/interfaceIDID.html#af7387d5e960a1c991d51f1004688703f", null ],
      [ "GetDIDName", "d3/da5/interfaceIDID.html#ad5edefe5b15c8936aff0b4d331f5817b", null ],
      [ "GetHistoryValue", "d3/da5/interfaceIDID.html#a6d9d0e4eb53e1220aa33fea9808845a0", null ],
      [ "GetPublicKey", "d3/da5/interfaceIDID.html#a0f702eb437b352a0f6044361c874768e", null ],
      [ "GetValue", "d3/da5/interfaceIDID.html#a747d7508bb377e6e106a2b460adc2718", null ],
      [ "SetValue", "d3/da5/interfaceIDID.html#a22f6545371894f4995d7660a6ec4c644", null ],
      [ "Sign", "d3/da5/interfaceIDID.html#ad1d3035af91d83dc40f3854c73bb1a5e", null ]
    ] ],
    [ "IDIDChecker", "d5/d40/interfaceIDIDChecker.html", [
      [ "CheckDID", "d5/d40/interfaceIDIDChecker.html#a50b4e8813b5a63426ba0484965aa15eb", null ],
      [ "CheckSign", "d5/d40/interfaceIDIDChecker.html#ac8fcde90ef665a093384f82a5df3755d", null ],
      [ "GetAllKeys", "d5/d40/interfaceIDIDChecker.html#ad3bf8759b42bcbbfa5368d813d5b7944", null ],
      [ "GetHistoryValue", "d5/d40/interfaceIDIDChecker.html#a0e57d156dca571b2e90a9c1fa7b6ae53", null ],
      [ "GetPublicKey", "d5/d40/interfaceIDIDChecker.html#a1f92771aae8d1ad77a6dbd113636c036", null ],
      [ "GetValue", "d5/d40/interfaceIDIDChecker.html#a16c2a8f315b0d07eed19746abd41a244", null ]
    ] ],
    [ "IDIDManager", "d3/dff/interfaceIDIDManager.html", [
      [ "CreateDID", "d3/dff/interfaceIDIDManager.html#a24a4b54e7fa2f1c2ce22df5d3fbea064", null ],
      [ "DestoryDID", "d3/dff/interfaceIDIDManager.html#a3c9b19304f42968a79b341c6d07756dd", null ],
      [ "GetDID", "d3/dff/interfaceIDIDManager.html#aa8d2fff2408cde26713c987b559789a7", null ],
      [ "GetDIDList", "d3/dff/interfaceIDIDManager.html#a82eb41ab7497cebcc7b394f4d70c7092", null ],
      [ "RegisterCallback", "d3/dff/interfaceIDIDManager.html#a3f37d6756b3d20670e4a8ea7be45a0bb", null ],
      [ "UnregisterCallback", "d3/dff/interfaceIDIDManager.html#a7911a118236aea35d8b34be41a727121", null ]
    ] ],
    [ "IDIDManagerCallback", "d0/d5a/interfaceIDIDManagerCallback.html", [
      [ "OnIdStatusChanged", "d0/d5a/interfaceIDIDManagerCallback.html#ab5bc14a1d816fbad938d834e44d97389", null ]
    ] ],
    [ "constructor", "d4/d12/group__DIDAPI.html#gac81f05bb2d5b9c2738d974846621de72", null ]
];