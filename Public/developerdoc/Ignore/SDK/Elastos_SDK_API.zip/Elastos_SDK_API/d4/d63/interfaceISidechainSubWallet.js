var interfaceISidechainSubWallet =
[
    [ "CreateWithdrawTransaction", "d4/d63/interfaceISidechainSubWallet.html#a28e1f3947ba84e42dc55bcb55a237af3", null ],
    [ "GetGenesisAddress", "d4/d63/interfaceISidechainSubWallet.html#a7b8e461d50382bbd3a00de967463cb13", null ]
];