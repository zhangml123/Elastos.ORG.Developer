var structReleaseOpWrapper_3_01T_00_01TRUE_00_01TRUE_01_4 =
[
    [ "operator()", "d4/de7/structReleaseOpWrapper_3_01T_00_01TRUE_00_01TRUE_01_4.html#ab0f5dc1f327b2e3b0fc988e34d368c40", null ]
];