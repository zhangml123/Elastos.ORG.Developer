var interfaceIFriend =
[
    [ "GetLabel", "dc/ddd/interfaceIFriend.html#ac206993268c1abe21e8fb467444ad955", null ],
    [ "GetName", "dc/ddd/interfaceIFriend.html#aa46a7f570fb370c5c3ae6404c1daeff8", null ],
    [ "GetUid", "dc/ddd/interfaceIFriend.html#a44201d0f299db1e27230b5416916f8bb", null ],
    [ "IsOnline", "dc/ddd/interfaceIFriend.html#a826247d9fc1b1be4d0191c333dab5e1e", null ],
    [ "SetLabel", "dc/ddd/interfaceIFriend.html#a62e8942e1e4e11543b4c73ed3b580410", null ]
];