var structQuintetObjectReleaseOp =
[
    [ "operator()", "dc/d45/structQuintetObjectReleaseOp.html#a4b95addbc258b33f3fd2034ef3b7983c", null ]
];