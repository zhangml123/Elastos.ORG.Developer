var interfaceIFunctionInfo =
[
    [ "GetAllParamInfos", "dc/deb/interfaceIFunctionInfo.html#a62e1920e529543a7737d2e50b3810fe4", null ],
    [ "GetName", "dc/deb/interfaceIFunctionInfo.html#a01ccff1da693db0a5d844828fc36623d", null ],
    [ "GetParamCount", "dc/deb/interfaceIFunctionInfo.html#a15fdfffb240f3e6355310d23ca480365", null ],
    [ "GetParamInfoByIndex", "dc/deb/interfaceIFunctionInfo.html#a5e4aa59679eaa826fe827d65f0343a93", null ],
    [ "GetParamInfoByName", "dc/deb/interfaceIFunctionInfo.html#a8cab660a020d514c6e37785462d063bc", null ],
    [ "GetSignature", "dc/deb/interfaceIFunctionInfo.html#a73d1ee50519f37b60145065e53ad9ff5", null ]
];