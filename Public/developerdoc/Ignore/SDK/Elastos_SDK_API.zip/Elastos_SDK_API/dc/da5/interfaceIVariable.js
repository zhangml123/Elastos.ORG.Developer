var interfaceIVariable =
[
    [ "GetPayload", "dc/da5/interfaceIVariable.html#ad2b69650cee3e6c88fbd5f86bc672247", null ],
    [ "GetTypeInfo", "dc/da5/interfaceIVariable.html#a6afda6fa0d3da5605629185c1df3dee3", null ],
    [ "Rebox", "dc/da5/interfaceIVariable.html#a26833c4d0632f85bc621bb2fd3f9543a", null ]
];