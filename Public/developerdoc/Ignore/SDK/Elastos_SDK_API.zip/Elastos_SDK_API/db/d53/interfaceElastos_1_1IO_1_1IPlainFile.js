var interfaceElastos_1_1IO_1_1IPlainFile =
[
    [ "Delete", "db/d53/interfaceElastos_1_1IO_1_1IPlainFile.html#ae4d268410fa5b37f7b555372769d08d3", null ],
    [ "Exists", "db/d53/interfaceElastos_1_1IO_1_1IPlainFile.html#ae58f83f3981b9d856f1d81478ccf0852", null ],
    [ "GetPath", "db/d53/interfaceElastos_1_1IO_1_1IPlainFile.html#a5556ea7182d6c16885867b8192a674b9", null ],
    [ "IsDir", "db/d53/interfaceElastos_1_1IO_1_1IPlainFile.html#af21fb37a1d3617b89235efcdf05e255b", null ],
    [ "IsFile", "db/d53/interfaceElastos_1_1IO_1_1IPlainFile.html#afd385ea4b6419363925a64a23dc7253a", null ],
    [ "Mkdir", "db/d53/interfaceElastos_1_1IO_1_1IPlainFile.html#a1f1d6202da9b57f8c8a0c712dec0a7ca", null ],
    [ "Mkdirs", "db/d53/interfaceElastos_1_1IO_1_1IPlainFile.html#a9f9ed7c7176c82b283f0dd121840e509", null ],
    [ "Read", "db/d53/interfaceElastos_1_1IO_1_1IPlainFile.html#a775470e0e5aa6105eda92aeb3cb4a35b", null ],
    [ "Write", "db/d53/interfaceElastos_1_1IO_1_1IPlainFile.html#a3a365959d1ce045714fc6d5f383a7c5b", null ]
];