var group__WalletAPI =
[
    [ "CMasterWalletManager", "de/ded/classCMasterWalletManager.html", [
      [ "constructor", "de/ded/classCMasterWalletManager.html#a3e5c468427b9c9325139d56e889e2001", null ]
    ] ],
    [ "IIdChainSubWallet", "dd/d63/interfaceIIdChainSubWallet.html", [
      [ "CreateIdTransaction", "dd/d63/interfaceIIdChainSubWallet.html#a8a937f5fdd48b80a1714b8a0a334c8f3", null ]
    ] ],
    [ "IMainchainSubWallet", "dc/d26/interfaceIMainchainSubWallet.html", [
      [ "CreateDepositTransaction", "dc/d26/interfaceIMainchainSubWallet.html#aa0c8e43ddbf01bcc59291f0e54ac9c06", null ]
    ] ],
    [ "IMasterWallet", "d4/d74/interfaceIMasterWallet.html", [
      [ "ChangePassword", "d4/d74/interfaceIMasterWallet.html#aca23d07f134baa51261ed6165f9ce13b", null ],
      [ "CheckSign", "d4/d74/interfaceIMasterWallet.html#aa1c4eb0e69d86a51d754a205802388eb", null ],
      [ "CreateSubWallet", "d4/d74/interfaceIMasterWallet.html#a79351fec9349b0794db6d8cf4d16b885", null ],
      [ "DestroyWallet", "d4/d74/interfaceIMasterWallet.html#af40aa5deb79114db7d33295b6a19fd68", null ],
      [ "GetAllSubWallets", "d4/d74/interfaceIMasterWallet.html#ae6635c6a2e5a70f151272ff92e7e6f21", null ],
      [ "GetId", "d4/d74/interfaceIMasterWallet.html#acc9f1b36d07b1bb4d95633fa45af3a7b", null ],
      [ "GetPublicKey", "d4/d74/interfaceIMasterWallet.html#a871a2630c35e606f9765c43f28778186", null ],
      [ "GetSupportedChains", "d4/d74/interfaceIMasterWallet.html#af60fdb7d1abc1c908b97c9fdfd9bd84f", null ],
      [ "IsAddressValid", "d4/d74/interfaceIMasterWallet.html#ace25232f8ae3b9d166bb76fe9574dfbd", null ],
      [ "RecoverSubWallet", "d4/d74/interfaceIMasterWallet.html#ab9addd4528fd4ae6804d2f8f737d2846", null ],
      [ "Sign", "d4/d74/interfaceIMasterWallet.html#ac97b6817a9e58d8f37fd8f377f257f96", null ]
    ] ],
    [ "IMasterWalletManager", "d3/d90/interfaceIMasterWalletManager.html", [
      [ "CreateMasterWallet", "d3/d90/interfaceIMasterWalletManager.html#ab3c125ba4d21b99af9608706790b9f33", null ],
      [ "DestroyWallet", "d3/d90/interfaceIMasterWalletManager.html#a474c301907720702a5ae08a4bb484cf2", null ],
      [ "ExportWalletWithKeystore", "d3/d90/interfaceIMasterWalletManager.html#a75d6b50a99eeca7db4044ff0ed0a5878", null ],
      [ "ExportWalletWithMnemonic", "d3/d90/interfaceIMasterWalletManager.html#aaedf0b3805c6c1ddb35beb84c521804a", null ],
      [ "GenerateMnemonic", "d3/d90/interfaceIMasterWalletManager.html#a0467519c3b3ebba8b50ddc720a1124fa", null ],
      [ "GetAllMasterWallets", "d3/d90/interfaceIMasterWalletManager.html#ac1047e05afa11e2c9f738b9299a03c2c", null ],
      [ "ImportWalletWithKeystore", "d3/d90/interfaceIMasterWalletManager.html#a21fa60a9feb4bf4331806a57ae82c07e", null ],
      [ "ImportWalletWithMnemonic", "d3/d90/interfaceIMasterWalletManager.html#a2f3bbfa4e641f7d152fb75bf0887e856", null ],
      [ "SaveConfigs", "d3/d90/interfaceIMasterWalletManager.html#a8d553edf2528e2a437126b21eec7c38c", null ]
    ] ],
    [ "ISidechainSubWallet", "d4/d63/interfaceISidechainSubWallet.html", [
      [ "CreateWithdrawTransaction", "d4/d63/interfaceISidechainSubWallet.html#a28e1f3947ba84e42dc55bcb55a237af3", null ],
      [ "GetGenesisAddress", "d4/d63/interfaceISidechainSubWallet.html#a7b8e461d50382bbd3a00de967463cb13", null ]
    ] ],
    [ "ISubWallet", "dd/d67/interfaceISubWallet.html", [
      [ "AddCallback", "dd/d67/interfaceISubWallet.html#a440ca0fbe5eed0696d819194bae739d7", null ],
      [ "CalculateTransactionFee", "dd/d67/interfaceISubWallet.html#a14f133f59c4a2e1b9c02039dfc070b67", null ],
      [ "CheckSign", "dd/d67/interfaceISubWallet.html#a3630513f1933cd6301d9b6eb093cda4c", null ],
      [ "CreateAddress", "dd/d67/interfaceISubWallet.html#adaf388969f34c2aa1207dcec35865d46", null ],
      [ "CreateMultiSignAddress", "dd/d67/interfaceISubWallet.html#a11537ecb8879f74b92270b6447e52429", null ],
      [ "CreateMultiSignTransaction", "dd/d67/interfaceISubWallet.html#abde448fd70e3416a91fb4d64e9531f54", null ],
      [ "CreateTransaction", "dd/d67/interfaceISubWallet.html#ac00212a67827d516572a3478f3a2b5b2", null ],
      [ "GetAllAddress", "dd/d67/interfaceISubWallet.html#a0112d7ba6e3c1a073af0ddf308078a70", null ],
      [ "GetAllTransaction", "dd/d67/interfaceISubWallet.html#ab8b9a277679a02fe2cea83f5b5aa16bd", null ],
      [ "GetBalance", "dd/d67/interfaceISubWallet.html#a8cd6a8f3c0df817a9ece4938f336d24a", null ],
      [ "GetBalanceInfo", "dd/d67/interfaceISubWallet.html#afe7fe11e714fb3da895a2b8965f32565", null ],
      [ "GetBalanceWithAddress", "dd/d67/interfaceISubWallet.html#aeb9d30e0b4a7df0bac69cbd01392c87d", null ],
      [ "GetChainId", "dd/d67/interfaceISubWallet.html#a89a2c8776388966f40a379a9f1032ccf", null ],
      [ "RemoveCallback", "dd/d67/interfaceISubWallet.html#a67ff59f6901e99ac86d94fed0c1c8802", null ],
      [ "SendRawTransaction", "dd/d67/interfaceISubWallet.html#aeaa1c9d6f17dfec16ca4f50fa50066f9", null ],
      [ "Sign", "dd/d67/interfaceISubWallet.html#ad68877661080cd5690fcc446ec337cbb", null ]
    ] ],
    [ "ISubWalletListener", "d3/d83/interfaceISubWalletListener.html", [
      [ "OnBlockHeightIncreased", "d3/d83/interfaceISubWalletListener.html#a3676306f953cc9fc43c433abd2f327b7", null ],
      [ "OnBlockSyncStarted", "d3/d83/interfaceISubWalletListener.html#a3746d6e7695cc0ab7dfd48fee905879a", null ],
      [ "OnBlockSyncStopped", "d3/d83/interfaceISubWalletListener.html#a44058e4bb85571ce46042e0b03b26c21", null ],
      [ "OnTransactionStatusChanged", "d3/d83/interfaceISubWalletListener.html#ae57814c42f564b13df70a26b22204ca5", null ]
    ] ]
];