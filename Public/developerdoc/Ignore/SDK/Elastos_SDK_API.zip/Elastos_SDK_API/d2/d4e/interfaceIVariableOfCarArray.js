var interfaceIVariableOfCarArray =
[
    [ "GetGetter", "d2/d4e/interfaceIVariableOfCarArray.html#accc72fa10a68c1926aef1a4e6051902f", null ],
    [ "GetSetter", "d2/d4e/interfaceIVariableOfCarArray.html#a7bdd727ec7a311f3ba51a69eaea76430", null ]
];