var classElastos_1_1IO_1_1CPlainFile =
[
    [ "constructor", "d2/d57/classElastos_1_1IO_1_1CPlainFile.html#a632eae4bf7cd23a147388608ac3f0014", null ],
    [ "constructor", "d2/d57/classElastos_1_1IO_1_1CPlainFile.html#a021420e566cb460dd7f8ce952e53140d", null ]
];