var interfaceICarrier =
[
    [ "AccpetFriendRequest", "d3/d85/interfaceICarrier.html#ae9227c870f7d31d566fcd5444c59924a", null ],
    [ "AddCarrierNodeListener", "d3/d85/interfaceICarrier.html#ae1a1c973604663b3b49a444c8cfac4a3", null ],
    [ "AddFriend", "d3/d85/interfaceICarrier.html#af6b0d9664558b8d9e6af8e93389a7b70", null ],
    [ "ClosePortForwarding", "d3/d85/interfaceICarrier.html#a7478cf74ec27f37ee94ec509b403c6f3", null ],
    [ "Export", "d3/d85/interfaceICarrier.html#a345c903a1d7f1fcb22b18649b3caf362", null ],
    [ "GetAddress", "d3/d85/interfaceICarrier.html#a04e3ef835fc4cdd8c5659b3d27bcd0d8", null ],
    [ "GetFriend", "d3/d85/interfaceICarrier.html#a792c9bdf8fcc34c0c1b7321c6cebed54", null ],
    [ "GetFriends", "d3/d85/interfaceICarrier.html#a98f0dbdb881574f7961eaa59c2b7eca7", null ],
    [ "GetUserid", "d3/d85/interfaceICarrier.html#a917739288450a4a2aad507f0bb3cce1f", null ],
    [ "Import", "d3/d85/interfaceICarrier.html#ab0f1f67a07fa6c7078c5b8642f886b83", null ],
    [ "IsOnline", "d3/d85/interfaceICarrier.html#a2d1178af72324220bfcbd54fd4fd7a18", null ],
    [ "OpenPortForwarding", "d3/d85/interfaceICarrier.html#afc66053efe07c6b4f553d84d250e9b46", null ],
    [ "RegenerateAddress", "d3/d85/interfaceICarrier.html#a205d277042d40a60eef5fc8405b4682f", null ],
    [ "RemoveCarrierNodeListener", "d3/d85/interfaceICarrier.html#adcdb0bd99f1ccf5617da1f270852819f", null ],
    [ "RemoveFriend", "d3/d85/interfaceICarrier.html#a4d22594e3774db6416c676bd9474cb87", null ],
    [ "SendMessage", "d3/d85/interfaceICarrier.html#aa0efa51ec741a4b33af21fb80ea20c5f", null ],
    [ "Start", "d3/d85/interfaceICarrier.html#a901d45366d7b7b2afbe025ce87d9bcc0", null ],
    [ "Stop", "d3/d85/interfaceICarrier.html#abf49348546f71e10bbc770a2601accdf", null ]
];