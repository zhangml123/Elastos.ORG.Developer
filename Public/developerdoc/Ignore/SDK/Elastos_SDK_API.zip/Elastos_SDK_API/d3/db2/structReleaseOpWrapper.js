var structReleaseOpWrapper =
[
    [ "operator()", "d3/db2/structReleaseOpWrapper.html#a87f4613df68891bc70f1626fea71acf1", null ]
];