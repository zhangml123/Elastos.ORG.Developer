var interfaceIDID =
[
    [ "CheckSign", "d3/da5/interfaceIDID.html#a7abbfe689e2364c2aa64822178c99534", null ],
    [ "GenerateProgram", "d3/da5/interfaceIDID.html#a6ef1cf2a4845e68c22bb56ebb8af1341", null ],
    [ "GetAllKeys", "d3/da5/interfaceIDID.html#af7387d5e960a1c991d51f1004688703f", null ],
    [ "GetDIDName", "d3/da5/interfaceIDID.html#ad5edefe5b15c8936aff0b4d331f5817b", null ],
    [ "GetHistoryValue", "d3/da5/interfaceIDID.html#a6d9d0e4eb53e1220aa33fea9808845a0", null ],
    [ "GetPublicKey", "d3/da5/interfaceIDID.html#a0f702eb437b352a0f6044361c874768e", null ],
    [ "GetValue", "d3/da5/interfaceIDID.html#a747d7508bb377e6e106a2b460adc2718", null ],
    [ "SetValue", "d3/da5/interfaceIDID.html#a22f6545371894f4995d7660a6ec4c644", null ],
    [ "Sign", "d3/da5/interfaceIDID.html#ad1d3035af91d83dc40f3854c73bb1a5e", null ]
];