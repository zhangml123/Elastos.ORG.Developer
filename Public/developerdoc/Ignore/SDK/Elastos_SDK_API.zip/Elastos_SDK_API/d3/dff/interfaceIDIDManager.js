var interfaceIDIDManager =
[
    [ "CreateDID", "d3/dff/interfaceIDIDManager.html#a24a4b54e7fa2f1c2ce22df5d3fbea064", null ],
    [ "DestoryDID", "d3/dff/interfaceIDIDManager.html#a3c9b19304f42968a79b341c6d07756dd", null ],
    [ "GetDID", "d3/dff/interfaceIDIDManager.html#aa8d2fff2408cde26713c987b559789a7", null ],
    [ "GetDIDList", "d3/dff/interfaceIDIDManager.html#a82eb41ab7497cebcc7b394f4d70c7092", null ],
    [ "RegisterCallback", "d3/dff/interfaceIDIDManager.html#a3f37d6756b3d20670e4a8ea7be45a0bb", null ],
    [ "UnregisterCallback", "d3/dff/interfaceIDIDManager.html#a7911a118236aea35d8b34be41a727121", null ]
];