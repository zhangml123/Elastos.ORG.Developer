var interfaceIDataTypeInfo =
[
    [ "GetDataType", "d3/d60/interfaceIDataTypeInfo.html#a55121a69d1d0a2a2e1e1d893ab3759bd", null ],
    [ "GetName", "d3/d60/interfaceIDataTypeInfo.html#a1650def673edbd86270384326bf91f5b", null ],
    [ "GetSize", "d3/d60/interfaceIDataTypeInfo.html#aafa4602711d8ef32b5600ae66ab78a52", null ]
];