var interfaceIVariableOfStruct =
[
    [ "GetGetter", "d3/d4c/interfaceIVariableOfStruct.html#acf67d0b9a4f840a135000efd2fcffeac", null ],
    [ "GetSetter", "d3/d4c/interfaceIVariableOfStruct.html#ac23c25b5d2a8930687d8a2fd148654f2", null ]
];