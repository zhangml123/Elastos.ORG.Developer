var interfaceIMasterWalletManager =
[
    [ "CreateMasterWallet", "d3/d90/interfaceIMasterWalletManager.html#ab3c125ba4d21b99af9608706790b9f33", null ],
    [ "DestroyWallet", "d3/d90/interfaceIMasterWalletManager.html#a474c301907720702a5ae08a4bb484cf2", null ],
    [ "ExportWalletWithKeystore", "d3/d90/interfaceIMasterWalletManager.html#a75d6b50a99eeca7db4044ff0ed0a5878", null ],
    [ "ExportWalletWithMnemonic", "d3/d90/interfaceIMasterWalletManager.html#aaedf0b3805c6c1ddb35beb84c521804a", null ],
    [ "GenerateMnemonic", "d3/d90/interfaceIMasterWalletManager.html#a0467519c3b3ebba8b50ddc720a1124fa", null ],
    [ "GetAllMasterWallets", "d3/d90/interfaceIMasterWalletManager.html#ac1047e05afa11e2c9f738b9299a03c2c", null ],
    [ "ImportWalletWithKeystore", "d3/d90/interfaceIMasterWalletManager.html#a21fa60a9feb4bf4331806a57ae82c07e", null ],
    [ "ImportWalletWithMnemonic", "d3/d90/interfaceIMasterWalletManager.html#a2f3bbfa4e641f7d152fb75bf0887e856", null ],
    [ "SaveConfigs", "d3/d90/interfaceIMasterWalletManager.html#a8d553edf2528e2a437126b21eec7c38c", null ]
];