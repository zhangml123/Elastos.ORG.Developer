var interfaceILocalPtrInfo =
[
    [ "GetPtrLevel", "d3/d84/interfaceILocalPtrInfo.html#a8c1b55b4137451df1684966504ed6181", null ],
    [ "GetTargetTypeInfo", "d3/d84/interfaceILocalPtrInfo.html#a723782e6fd63023e90b7b53e16d6c7fc", null ]
];