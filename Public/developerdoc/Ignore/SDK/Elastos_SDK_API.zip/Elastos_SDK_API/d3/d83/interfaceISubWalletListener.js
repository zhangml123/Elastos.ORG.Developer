var interfaceISubWalletListener =
[
    [ "OnBlockHeightIncreased", "d3/d83/interfaceISubWalletListener.html#a3676306f953cc9fc43c433abd2f327b7", null ],
    [ "OnBlockSyncStarted", "d3/d83/interfaceISubWalletListener.html#a3746d6e7695cc0ab7dfd48fee905879a", null ],
    [ "OnBlockSyncStopped", "d3/d83/interfaceISubWalletListener.html#a44058e4bb85571ce46042e0b03b26c21", null ],
    [ "OnTransactionStatusChanged", "d3/d83/interfaceISubWalletListener.html#ae57814c42f564b13df70a26b22204ca5", null ]
];