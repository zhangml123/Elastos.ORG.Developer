var interfaceIAnnotationInfo =
[
    [ "GetKeys", "d6/d03/interfaceIAnnotationInfo.html#ace9f86464bff8d8311e501cd24cdf2a5", null ],
    [ "GetName", "d6/d03/interfaceIAnnotationInfo.html#adfe1ca43b3dd59f90ee6521f86d9dcc7", null ],
    [ "GetNamespace", "d6/d03/interfaceIAnnotationInfo.html#a156c64853529d52eace4520a78f2a376", null ],
    [ "GetSize", "d6/d03/interfaceIAnnotationInfo.html#a6bf8cf13f67ab8a1c9136e319b20e949", null ],
    [ "GetValue", "d6/d03/interfaceIAnnotationInfo.html#ab3efc4ad6454d65e0496f475cb8ebd70", null ],
    [ "GetValues", "d6/d03/interfaceIAnnotationInfo.html#a6d427bd0dab9074431cbd1adb1c75f49", null ]
];