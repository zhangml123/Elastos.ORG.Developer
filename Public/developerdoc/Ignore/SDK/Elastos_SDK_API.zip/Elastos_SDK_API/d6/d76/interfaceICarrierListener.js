var interfaceICarrierListener =
[
    [ "OnConnectionChanged", "d6/d76/interfaceICarrierListener.html#a0f2def6821a38876a58893ee3f3c7d5e", null ],
    [ "OnFriendConnetionChanged", "d6/d76/interfaceICarrierListener.html#a0d35e556bb45eb6019cbc8e3b795e929", null ],
    [ "OnFriendRequest", "d6/d76/interfaceICarrierListener.html#a88548f9dd891078e2d13cc9cd6582781", null ],
    [ "OnIdle", "d6/d76/interfaceICarrierListener.html#a4d43b185fee88a5c8d0ca5fb57f4896e", null ],
    [ "OnMessageReceived", "d6/d76/interfaceICarrierListener.html#a916b97bdb533a550976682e2c15b695d", null ],
    [ "OnPortForwardingRequest", "d6/d76/interfaceICarrierListener.html#af9eeb8827f1b2a5fa64bfa3dbfd2a234", null ],
    [ "OnPortForwardingResult", "d6/d76/interfaceICarrierListener.html#ac16a4ac30dc0afed96a27adc859bbf0d", null ],
    [ "OnReady", "d6/d76/interfaceICarrierListener.html#a20c713b710f20cef20fd5194d1ebae65", null ]
];